package com.nominalista.expenses.addeditexpense.presentation.tagselection

class AddTagItemModel :
    TagSelectionItemModel {

    var click: (() -> Unit)? = null
}