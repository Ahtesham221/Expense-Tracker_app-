package com.nominalista.expenses.home.presentation

import android.view.View
import androidx.recyclerview.widget.RecyclerView

abstract class HomeItemHolder(itemView: View) : RecyclerView.ViewHolder(itemView)