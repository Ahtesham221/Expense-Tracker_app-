package com.nominalista.expenses.util.extensions

fun Double.toExactFloat() = toString().toFloat()