package com.nominalista.expenses.home.presentation

interface HomeItemModel