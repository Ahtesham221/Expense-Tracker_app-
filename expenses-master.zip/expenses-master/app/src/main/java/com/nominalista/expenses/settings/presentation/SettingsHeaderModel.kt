package com.nominalista.expenses.settings.presentation

class SettingsHeaderModel(val title: String) : SettingItemModel