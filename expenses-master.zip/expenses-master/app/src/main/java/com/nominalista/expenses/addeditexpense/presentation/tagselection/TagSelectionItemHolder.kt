package com.nominalista.expenses.addeditexpense.presentation.tagselection

import android.view.View
import androidx.recyclerview.widget.RecyclerView

abstract class TagSelectionItemHolder(view: View) : RecyclerView.ViewHolder(view)