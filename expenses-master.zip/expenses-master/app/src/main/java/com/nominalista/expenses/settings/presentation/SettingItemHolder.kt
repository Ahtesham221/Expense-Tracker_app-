package com.nominalista.expenses.settings.presentation

import android.view.View
import androidx.recyclerview.widget.RecyclerView

abstract class SettingItemHolder(itemView: View) : RecyclerView.ViewHolder(itemView)