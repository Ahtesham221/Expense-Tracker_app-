package com.nominalista.expenses.util.extensions

fun Float.toExactDouble() = toString().toDouble()